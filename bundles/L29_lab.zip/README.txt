ECE 444 recorded radar data: the fallback for the L28-L31 Labs.

Simulated ADALM-PHASER FMCW captures in the course capture format, written by
scripts/radar/fmcw_sim.py (re-run it to regenerate). Each .npz holds:
  iq      complex64, n_chirps x n_samples, summed array, one chirp a row, 0 dBFS = |iq| 1
  iq_ch   complex64, 2 x n_chirps x n_samples, the two subarray halves (sum = iq)
  fs, fc, B, T_ramp, PRI, f0   (Hz, Hz, Hz, s, s, Hz)
  note    what the capture holds

L28, the Phaser app's Range (Basic) preset (12.145 GHz, 500 MHz, 1 ms, 0.6 MSPS):
32 chirps a capture, each the part of a chirp the app keeps, one every 50 ms;
iq only. The simulated kit's 0 m frequency is 101.4 kHz; the tape readings carry
a real room's few-centimeter errors.
  L28_clear.npz             nothing in front of the kit: the leakage and the far wall; f0 field = 100 kHz, the IF tone
  L28_cal_0m.npz            plate against the array, for the 0 m calibration; f0 field = 100 kHz
  L28_corner_{1,2,3}m.npz   10 cm corner reflector at 1, 2, 3 m by the tape; f0 field = 101.4 kHz
  L28_corner_2m_fast.npz    the 2 m corner at the app's Range (Fast) preset: 10 GHz, 500 MHz in
                            0.5 ms, 5 MSPS
  L28_corner_2m_B250.npz    the 2 m corner at B = 250 MHz, otherwise Range (Basic)
  L28_two_corners.npz       corners at 2.0 and 2.2 m, closer than one resolution cell
  L28_walker.npz            a person walking 1 m -> 4 m -> 1 m at 1 m/s, 200 chirps, 10 s

L29 (the Phaser app's range_doppler preset, "Range + Velocity": 9.9 GHz, 256 chirps of 300 us,
PRI 0.5 ms, 2 MSPS, 500 MHz, f0 101.4 kHz; iq only, no iq_ch, 1.2 MB each; a wall at 2.5 m in every
burst), written by scripts/radar/make_l29_data.py (fmcw_sim's l29_sets):
  L29_static.npz              the leakage and the wall, nothing moving
  L29_hand_closing.npz        a hand from 1.0 m toward the kit at 1.0 m/s
  L29_hand_opening.npz        a hand from 0.7 m away from the kit at 1.5 m/s
  L29_hand_closing_B200.npz   the closing hand at B = 200 MHz
  L29_hand_still.npz          a hand held still at 0.8 m, with a 2 mm tremor
  L29_hand_across.npz         a hand moved side to side across the beam at 0.8 m, 0.20 m either way at 1 Hz
  L29_spinner.npz             a fidget spinner edge-on at 0.5 m: three arms on a
                              3 cm radius at 15 rev/s
  L29_spinner_faceon.npz      the same spinner turned face-on, held 10 deg off, so 0.17 of its swing
                              reaches the line of sight
The simulated chirps are timed perfectly, so a pulse canceller removes the wall
completely; no kit does. Load Capture in the Phaser app plays any of these as if live.
L30, written by scripts/radar/make_l30_data.py on two of the Phaser app's presets; iq only, no iq_ch:
  Range (CFAR), 0.5 ms chirps of 500 MHz at 10 GHz, 2 MSPS, f0 101.4 kHz, one chirp a display update,
  as the app's Save Capture writes it (the app's CFAR overlay runs on this range profile):
  L30_range_person.npz      a person standing still at 3.0 m, a wall at 6.0 m; 32 updates 50 ms apart:
                            Procedure A
  L30_walker.npz            a person walking 1.0 m -> 4.5 m -> 1.0 m toward a wall at 6.0 m; one update
                            every 0.1 s (PRI 0.1 s), 70 updates: Procedure B
  L30_range_empty.npz       noise and the kit's leakage, no target; 32 updates 50 ms apart: Procedure C
  Range + Velocity, one burst of 256 chirps of 300 us, PRI 0.5 ms, 500 MHz at 9.9 GHz, 2 MSPS, f0 101.4 kHz:
  L30_empty.npz             noise and the kit's leakage, no target: false alarms, task (a)
  L30_wall_hand.npz         a wall at 5.0 m and a hand waving at about 2.3-2.6 m: tasks (b) and (c)
  L30_weak_strong.npz       a strong mover at 4.2 m, +0.6 m/s, and a weak one at 3.0 m, +0.5 m/s: masking
L31, written by scripts/radar/make_l31_data.py (fmcw_sim's add_fan, add_rotor and add_dismount);
each iq rounded to 12-bit steps and saved compressed, 1.2-2.7 MB a file, 24.8 MB in all; the
Phaser app's Range + Velocity preset (9.9 GHz, 500 MHz, 300 us, PRI 0.5 ms, 2 MSPS), and each
plays in the app's Load Capture:
  L31_<target>_<n>.npz      n = 1-4 for walker, fan, spinner, hand: 2.0 s of back-to-back chirps
                            (300 us, PRI 0.5 ms, 500 MHz), 4000 chirps, resampled to 90 samples a chirp
                            (0.3 MSPS: the same 0.30 m bins, reaching 4.4 m); iq only. Record 1 of each
                            target is the packet's Part 1 givens; 2-4 change speed, size, range and
                            tilt (the note says which). Steps 5-8 and tasks (a) and (b) without a kit
  L31_dismount.npz          a person walking from tape mark A to mark B on a diagonal (the note gives
                            their ranges and angles), turning, and back at 1 m/s, a chair at 3.2 m;
                            every 4th chirp (PRI 2 ms),
                            44 frames of 128 ms; iq and iq_ch, with truth_t, truth_r, truth_az per frame.
                            Steps 9-10, the angle at B, and task (c) without a kit
